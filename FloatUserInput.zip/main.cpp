#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[]) {
	float firstNumber;
	float secondNumber;
	printf("Enter two float number >>> " );
	scanf("%f%f", &firstNumber, &secondNumber);
  float sum;
  sum = firstNumber +secondNumber;
  printf("Sum = %f ", sum);
  float product;
  product = firstNumber * secondNumber;
  printf("Product = %f ", product);
  float difference;
  difference = firstNumber -secondNumber;
  printf("Difference = %f ", difference);
  float quotient;
  quotient = firstNumber /secondNumber;
  printf("Quotient = %f ", quotient);
  
}